# GENERATED VERSION FILE
# TIME: Thu Nov 24 19:48:29 2022
__version__ = '0.4.0'
__gitsha__ = 'c1d94d2'
version_info = (0, 4, 0)
