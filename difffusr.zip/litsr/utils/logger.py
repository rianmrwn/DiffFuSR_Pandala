import logging

logger = logging.getLogger("LitSR")
logger.setLevel(logging.INFO)
